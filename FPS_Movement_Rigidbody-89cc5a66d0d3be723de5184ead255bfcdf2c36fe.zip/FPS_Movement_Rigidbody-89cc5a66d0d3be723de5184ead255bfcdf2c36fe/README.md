#### Simple FPS Movement

A simple movement system for Unity, based on rigidbodies.

[For setup and usage, use this tutorial](https://youtu.be/XAC8U9-dTZU)
